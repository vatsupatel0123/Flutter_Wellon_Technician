import 'dart:async';
import 'dart:ui';

import 'package:flutter_web_browser/flutter_web_browser.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:wellon_partner_app/data/rest_ds.dart';
import 'package:wellon_partner_app/utils/connectionStatusSingleton.dart';
import 'package:wellon_partner_app/utils/internetconnection.dart';
import 'package:flutter/material.dart';

class ShopScreen extends StatefulWidget {
  @override
  _ShopScreenState createState() => _ShopScreenState();
}

class _ShopScreenState extends State<ShopScreen> {
  BuildContext _ctx;
  int counter = 0;

  bool _isLoading = false;
  final formKey = new GlobalKey<FormState>();
  final scaffoldKey = new GlobalKey<ScaffoldState>();
  bool passwordVisible = true;
  String _otpcode;

  bool isOffline = false;
  InternetConnection connection = new InternetConnection();
  StreamSubscription _connectionChangeStream;

  @override
  initState() {
    super.initState();
    print("setstate called");
    ConnectionStatusSingleton connectionStatus =
    ConnectionStatusSingleton.getInstance();
    connectionStatus.initialize();
    _connectionChangeStream =
        connectionStatus.connectionChange.listen(connectionChanged);
  }

  void connectionChanged(dynamic hasConnection) {
    setState(() {
      isOffline = !hasConnection;
      //print(isOffline);
    });
  }

  Future<void> _launchInBrowser(String url) async {
    if (await canLaunch(url)) {
      await launch(
        url,
        forceSafariVC: false,
        forceWebView: false,
        headers: <String, String>{'my_header_key': 'my_header_value'},
      );
    } else {
      throw 'Could not launch $url';
    }
  }
  openBrowserTab() async {
    await FlutterWebBrowser.openWebPage(url: "https://www.waterpurifieronline.com/", androidToolbarColor: Colors.lightGreenAccent);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text("Shopping",style: GoogleFonts.lato(color:Colors.white,letterSpacing: 1,fontWeight: FontWeight.w700),),
        iconTheme: IconThemeData(
          color: Colors.white, //change your color here
        ),
        backgroundColor: Colors.green,
      ),
      body:
          SingleChildScrollView(
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.only(top: 10,right: 5,left: 5),
                  child: Card(
                    elevation: 2.0,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(5),
                    ),
                    child: new Image.asset("images/banner2.png"),
                  ),
                ),
                InkWell(
                  onTap: () {
                    Navigator.of(context).pushNamed("/des");
                  },
                  child: Padding(
                    padding: const EdgeInsets.only(left: 8,right: 8),
                    child: Align(
                      alignment: Alignment.center,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: <Widget>[
                          InkWell(
                            onTap: () {
                            },
                            child: InkWell(
                              onTap: (){
                                openBrowserTab();
                              },
                              child: Container(
                                padding: EdgeInsets.symmetric(vertical: 20, horizontal:0),
                                alignment: Alignment.center,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.all(Radius.circular(05)),
                                  color: Colors.green,
                                ),
                                child: Text("Go To Website", style: GoogleFonts.lato(color:Colors.white,fontSize: 18,letterSpacing: 1,fontWeight: FontWeight.w700),),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          )

      // Stack(
      // children: <Widget>[
      //   ListView(
      //       padding: EdgeInsets.only(top: 5),
      //     children: <Widget>[
      //       Padding(
      //         padding: const EdgeInsets.fromLTRB(10, 10, 10, 20),
      //         child: Card(
      //           elevation: 2.0,
      //           shape: RoundedRectangleBorder(
      //             borderRadius: BorderRadius.circular(5),
      //           ),
      //           margin: new EdgeInsets.symmetric(
      //               horizontal: 0, vertical: 5.0),
      //           child: Container(
      //             child: Column(
      //                 children: <Widget>[
      //                   Container(
      //                       child: new Image.asset("images/banner2.png", width: 500, height: 484,)
      //                   ),
      //                   InkWell(
      //                     onTap: () {
      //                       Navigator.of(context).pushNamed("/des");
      //                     },
      //                     child: Align(
      //                       alignment: Alignment.center,
      //                       child: Column(
      //                         mainAxisAlignment: MainAxisAlignment.end,
      //                         children: <Widget>[
      //                           InkWell(
      //                             onTap: () {
      //                             },
      //                             child: InkWell(
      //                               onTap: (){
      //                                 openBrowserTab();
      //                               },
      //                               child: Container(
      //                                 padding: EdgeInsets.symmetric(vertical: 20, horizontal:0),
      //                                 alignment: Alignment.center,
      //                                 decoration: BoxDecoration(
      //                                   borderRadius: BorderRadius.all(Radius.circular(0)),
      //                                   color: Colors.green,
      //                                 ),
      //                                 child: Text("Go To Website", style: GoogleFonts.lato(color:Colors.white,fontSize: 15,letterSpacing: 1,fontWeight: FontWeight.w700),),
      //                               ),
      //                             ),
      //                           ),
      //                         ],
      //                       ),
      //                     ),
      //                   ),
      //
      //                 ]
      //             ),
      //           ),
      //         ),
      //       ),
      //     ]
      //    ),
      //     ]
      //   ),
    );
  }
}